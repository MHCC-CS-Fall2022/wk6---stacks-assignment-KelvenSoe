// Filename: testStacks2.cpp
// Author: Kelven Soe
// Date: 11/3/22
// Summary: Driver file for stack2 class (using stack2.h) to test

#include <iostream> // for cout, endl
#include <stack>    // provides stack
#include <cstdlib>  // provides EXIT_SUCCESS
#include "stacks2.h"
#include "node2.h"
using namespace std;
using namespace kelven_soe;

// PROTOTYPES


void showBottomToTop(std::stack<int>&);
// Precondition: check to see if stack is empty, if true returns
// Postcondition: prints out the values in the stack from bottom to top

bool compareStacks(std::stack<int>&, std::stack<int>&);
// Precondition: checks to see if either stacks are empty, if true returns false
// Postcondition: returns true if the two stacks have the same values in the
//		  same order


int main()
{
	int user_input;
	std::stack<int> s1;
	std::stack<int> s2;

	cout << "Enter up to 30 numbers, type negative to break out\n";
	for (int i = 0; i < 30; i++) // loop for inputs 
	{
		cin >> user_input;
		if(user_input < 0)
			break;
		s1.push(user_input);
	}

	showBottomToTop(s1);
	
	cout << "Enter up to 30 numbers, type negative to break out\n";
	for (int i = 0; i < 30; i++) // loop for inputs
	{
		cin >> user_input;
		if(user_input < 0)
			break;
		s2.push(user_input);
	}
	
	if(compareStacks(s1, s2) == true)
		cout << "They are alike!" << endl;
	else
		cout << "They aren't alike!" << endl;
		


	return 0;
}

void showBottomToTop(std::stack<int>& s)
{
	if(s.empty()) // checks to see if stack is empty
	{
		return; // if true returns to main
	}
	
	std::stack<int> temp;
	
	while(!s.empty()) // pushes integers from top to bottom into temp
	{
		temp.push(s.top());
		s.pop();
	}
	
	while(!temp.empty()) // loops to cout the top and keep on popping till empty
	{
		int num = temp.top();
		cout << num << " ";
		temp.pop();
		
		s.push(num);
	}
	cout << endl;
}

bool compareStacks(std::stack <int>& s1, std::stack<int>& s2)
{
	bool decide = true; // helps returns true or false
	if(s1.size() != s2.size()) // if not same size returns because not the same
	{                          // amount of numbers
		decide = false;
		return decide;
	}
	
	while(!s1.empty()) // makes sure that s1 isn't empty
	{
		if(s1.top() == s2.top()) // if both tops are same
		{
			s1.pop(); // pops out top for both until empty
			s2.pop();
		}
		else
		{
			decide = false;
			break;
		}
	}
	return decide;
}
